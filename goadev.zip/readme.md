<p align="center"><img src="https://scontent.fscl11-1.fna.fbcdn.net/v/t1.0-9/46754597_488001375023371_2040484270216052736_n.jpg?_nc_cat=1&_nc_ht=scontent.fscl11-1.fna&oh=24fc4ab5c242237e1ae90494c864760f&oe=5CFCD61E" width="200"></p>


## Acerca del proyecto
Este proyecto consiste en la creación de una página web la cual permita a los usuarios de la comunidad de Game Over Addiction poder registrarse en el sistema, para así poder nosotros como administración, tener un mejor control sobre eventos como torneos, competencias o cosas de ese estilo.
