    <div class="sidebar">
        <div class="gadget">
            <h2 class="star"><span>Sidebar</span> Menu</h2>
            <div class="clr"></div>
            <ul class="sb_menu">
                <li><a href="#">Home</a></li>
                <li><a href="#">TemplateInfo</a></li>
                <li><a href="#">Style Demo</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Archives</a></li>
                <li><a href="#">Web Templates</a></li>
            </ul>
        </div>
        <div class="gadget">
            <h2 class="star"><span>Afiliados</span></h2>
            <div class="clr"></div>
            <ul class="ex_menu">
                <li><a href="#">Tienda PUBG</a><br />
                    La mejor tienda de pubg mobile con las 3B!</li>
            </ul>
        </div>
    </div>